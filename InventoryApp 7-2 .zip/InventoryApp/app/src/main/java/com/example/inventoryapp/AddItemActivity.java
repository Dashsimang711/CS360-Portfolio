package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    private InventoryDatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        EditText itemName = findViewById(R.id.editItemName);
        EditText itemQuantity = findViewById(R.id.editItemQuantity);
        EditText itemDescription = findViewById(R.id.editItemDescription);

        Button saveButton = findViewById(R.id.buttonSaveItem);
        Button cancelButton = findViewById(R.id.buttonCancelItem);

        databaseHelper = new InventoryDatabaseHelper(this);

        saveButton.setOnClickListener(v -> {

            String name = itemName.getText().toString().trim();
            String quantityText = itemQuantity.getText().toString().trim();
            String description =
                    itemDescription.getText().toString().trim();

            if (name.isEmpty() || quantityText.isEmpty()) {

                Toast.makeText(
                        AddItemActivity.this,
                        "Please enter an item name and quantity.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            int quantity;

            try {
                quantity = Integer.parseInt(quantityText);
            } catch (NumberFormatException e) {

                Toast.makeText(
                        AddItemActivity.this,
                        "Quantity must be a number.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            long result = databaseHelper.addInventoryItem(
                    name,
                    quantity,
                    description
            );

            if (result != -1) {

                Toast.makeText(
                        AddItemActivity.this,
                        "Item saved successfully.",
                        Toast.LENGTH_SHORT
                ).show();

                Intent intent = new Intent(
                        AddItemActivity.this,
                        InventoryActivity.class
                );

                intent.putExtra("itemName", name);
                intent.putExtra(
                        "itemQuantity",
                        String.valueOf(quantity)
                );

                startActivity(intent);
                finish();

            } else {

                Toast.makeText(
                        AddItemActivity.this,
                        "Unable to save item.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        cancelButton.setOnClickListener(v -> finish());
    }
}