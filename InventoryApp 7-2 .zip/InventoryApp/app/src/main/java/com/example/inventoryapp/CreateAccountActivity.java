package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreateAccountActivity extends AppCompatActivity {

    private InventoryDatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        EditText username = findViewById(R.id.editNewUsername);
        EditText password = findViewById(R.id.editNewPassword);
        EditText confirmPassword = findViewById(R.id.editConfirmPassword);

        Button createAccountButton =
                findViewById(R.id.buttonCreateNewAccount);

        Button cancelButton =
                findViewById(R.id.buttonCancelAccount);

        databaseHelper = new InventoryDatabaseHelper(this);

        createAccountButton.setOnClickListener(v -> {

            String usernameText =
                    username.getText().toString().trim();

            String passwordText =
                    password.getText().toString().trim();

            String confirmPasswordText =
                    confirmPassword.getText().toString().trim();

            if (usernameText.isEmpty()
                    || passwordText.isEmpty()
                    || confirmPasswordText.isEmpty()) {

                Toast.makeText(
                        CreateAccountActivity.this,
                        "Please complete all fields.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            if (!passwordText.equals(confirmPasswordText)) {

                Toast.makeText(
                        CreateAccountActivity.this,
                        "Passwords do not match.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            long result = databaseHelper.createUser(
                    usernameText,
                    passwordText
            );

            if (result != -1) {

                Toast.makeText(
                        CreateAccountActivity.this,
                        "Account created successfully.",
                        Toast.LENGTH_SHORT
                ).show();

                Intent intent = new Intent(
                        CreateAccountActivity.this,
                        InventoryActivity.class
                );

                startActivity(intent);
                finish();

            } else {

                Toast.makeText(
                        CreateAccountActivity.this,
                        "Unable to create account.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        cancelButton.setOnClickListener(v -> finish());
    }
}