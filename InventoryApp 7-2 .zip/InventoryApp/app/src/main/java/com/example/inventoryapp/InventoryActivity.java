package com.example.inventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {

    private InventoryDatabaseHelper databaseHelper;

    private long itemId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new InventoryDatabaseHelper(this);

        Button addItemButton = findViewById(R.id.buttonAddItem);
        Button smsButton = findViewById(R.id.buttonSmsNotifications);

        Button deleteButton1 = findViewById(R.id.buttonDelete1);
        Button deleteButton2 = findViewById(R.id.buttonDelete2);
        Button deleteButton3 = findViewById(R.id.buttonDelete3);

        View row1 = findViewById(R.id.inventoryRow1);
        View row2 = findViewById(R.id.inventoryRow2);
        View row3 = findViewById(R.id.inventoryRow3);

        TextView itemName = findViewById(R.id.inventoryItemName);
        TextView itemQuantity = findViewById(R.id.inventoryItemQuantity);
        TextView itemStatus = findViewById(R.id.inventoryItemStatus);

        loadLatestInventoryItem(
                itemName,
                itemQuantity,
                itemStatus
        );

        addItemButton.setOnClickListener(v -> {

            Intent intent = new Intent(
                    InventoryActivity.this,
                    AddItemActivity.class
            );

            startActivity(intent);
        });

        smsButton.setOnClickListener(v -> {

            Intent intent = new Intent(
                    InventoryActivity.this,
                    SmsActivity.class
            );

            startActivity(intent);
        });

        deleteButton1.setOnClickListener(v -> {

            if (itemId != -1) {

                databaseHelper.deleteInventoryItem(itemId);

                row1.setVisibility(View.GONE);
            }
        });

        deleteButton2.setOnClickListener(v -> {
            row2.setVisibility(View.GONE);
        });

        deleteButton3.setOnClickListener(v -> {
            row3.setVisibility(View.GONE);
        });
    }

    private void loadLatestInventoryItem(
            TextView itemName,
            TextView itemQuantity,
            TextView itemStatus) {

        Cursor cursor = databaseHelper
                .getReadableDatabase()
                .rawQuery(
                        "SELECT id, item_name, quantity " +
                                "FROM inventory " +
                                "ORDER BY id DESC LIMIT 1",
                        null
                );

        if (cursor.moveToFirst()) {

            itemId = cursor.getLong(0);

            String name = cursor.getString(1);

            int quantity = cursor.getInt(2);

            itemName.setText(name);

            itemQuantity.setText(
                    String.valueOf(quantity)
            );

            if (quantity <= 2) {

                itemStatus.setText("Low Stock");

            } else {

                itemStatus.setText("In Stock");
            }
        }

        cursor.close();
    }
}