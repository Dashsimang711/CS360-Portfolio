package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class InventoryDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;

    public InventoryDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // User login table
        db.execSQL(
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT NOT NULL UNIQUE, " +
                        "password TEXT NOT NULL)"
        );

        // Inventory table
        db.execSQL(
                "CREATE TABLE inventory (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "item_name TEXT NOT NULL, " +
                        "quantity INTEGER NOT NULL, " +
                        "description TEXT)"
        );
    }

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS inventory");

        onCreate(db);
    }

    // Create a new user account
    public long createUser(
            String username,
            String password) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("username", username);
        values.put("password", password);

        return db.insert("users", null, values);
    }

    // Check username and password
    public boolean checkUser(
            String username,
            String password) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT id FROM users " +
                        "WHERE username = ? AND password = ?",
                new String[]{
                        username,
                        password
                }
        );

        boolean userExists = cursor.moveToFirst();

        cursor.close();

        return userExists;
    }

    // Add inventory item
    public long addInventoryItem(
            String itemName,
            int quantity,
            String description) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("item_name", itemName);
        values.put("quantity", quantity);
        values.put("description", description);

        return db.insert(
                "inventory",
                null,
                values
        );
    }

    // Delete inventory item
    public boolean deleteInventoryItem(long itemId) {

        SQLiteDatabase db = this.getWritableDatabase();

        int rowsDeleted = db.delete(
                "inventory",
                "id = ?",
                new String[]{
                        String.valueOf(itemId)
                }
        );

        return rowsDeleted > 0;
    }

    // Get the newest inventory item
    public Cursor getLatestInventoryItem() {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT id, item_name, quantity, description " +
                        "FROM inventory " +
                        "ORDER BY id DESC LIMIT 1",
                null
        );
    }
}