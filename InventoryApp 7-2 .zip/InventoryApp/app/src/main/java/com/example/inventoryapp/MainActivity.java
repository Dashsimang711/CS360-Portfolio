package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private InventoryDatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        EditText username = findViewById(R.id.editUsername);
        EditText password = findViewById(R.id.editPassword);

        Button loginButton = findViewById(R.id.buttonLogin);
        Button createAccountButton =
                findViewById(R.id.buttonCreateAccount);

        databaseHelper = new InventoryDatabaseHelper(this);

        loginButton.setOnClickListener(v -> {

            String usernameText =
                    username.getText().toString().trim();

            String passwordText =
                    password.getText().toString().trim();

            if (usernameText.isEmpty() || passwordText.isEmpty()) {

                Toast.makeText(
                        MainActivity.this,
                        "Please enter your username and password.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            boolean validUser = databaseHelper.checkUser(
                    usernameText,
                    passwordText
            );

            if (validUser) {

                Intent intent = new Intent(
                        MainActivity.this,
                        InventoryActivity.class
                );

                startActivity(intent);

            } else {

                Toast.makeText(
                        MainActivity.this,
                        "Invalid username or password.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        createAccountButton.setOnClickListener(v -> {

            Intent intent = new Intent(
                    MainActivity.this,
                    CreateAccountActivity.class
            );

            startActivity(intent);
        });
    }
}