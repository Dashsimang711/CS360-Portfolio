package com.example.inventoryapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private EditText phoneNumber;
    private CheckBox lowInventoryCheckBox;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms);

        phoneNumber = findViewById(R.id.editPhoneNumber);
        lowInventoryCheckBox = findViewById(R.id.checkLowInventory);
        statusText = findViewById(R.id.textSmsStatus);

        Button enableSmsButton =
                findViewById(R.id.buttonEnableSms);

        Button sendTestSmsButton =
                findViewById(R.id.buttonSendTestSms);

        enableSmsButton.setOnClickListener(v -> {

            if (!lowInventoryCheckBox.isChecked()) {

                statusText.setText(
                        "Select low inventory notifications before enabling SMS."
                );

                return;
            }

            checkSmsPermission();
        });

        sendTestSmsButton.setOnClickListener(v -> {

            String number =
                    phoneNumber.getText().toString().trim();

            if (number.isEmpty()) {

                statusText.setText(
                        "Please enter a phone number first."
                );

                return;
            }

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS
            ) != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{
                                Manifest.permission.SEND_SMS
                        },
                        SMS_PERMISSION_CODE
                );

                return;
            }

            sendTestMessage(number);
        });
    }

    private void checkSmsPermission() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.SEND_SMS
                    },
                    SMS_PERMISSION_CODE
            );

        } else {

            statusText.setText(
                    "SMS notifications are enabled for low inventory."
            );
        }
    }

    private void sendTestMessage(String number) {

        try {

            SmsManager smsManager = SmsManager.getDefault();

            smsManager.sendTextMessage(
                    number,
                    null,
                    "InventoryApp test: Your inventory notification system is working.",
                    null,
                    null
            );

            statusText.setText(
                    "Test SMS sent successfully."
            );

        } catch (Exception e) {

            statusText.setText(
                    "Unable to send test SMS."
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == SMS_PERMISSION_CODE) {

            if (grantResults.length > 0
                    && grantResults[0]
                    == PackageManager.PERMISSION_GRANTED) {

                statusText.setText(
                        "SMS permission granted. SMS notifications are enabled."
                );

            } else {

                statusText.setText(
                        "SMS permission was not granted. You can continue using the app."
                );
            }
        }
    }
}